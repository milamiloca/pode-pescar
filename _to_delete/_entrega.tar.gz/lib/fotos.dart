// GERADO POR ferramentas/fotos.py — NÃO EDITAR À MÃO.
//
// A lista abaixo sai de um pareamento GEOMÉTRICO entre o nome científico
// e a imagem da mesma linha do guia, feito pelo ferramentas/fotos.py.
// Onde o pareamento foi ambíguo — célula com quatro nomes e três fotos,
// por exemplo — o script RECUSOU e a espécie ficou sem foto. Ficha sem
// foto é melhor que foto do bicho errado.

// =====================================================================
// AS FOTOS DAS ESPÉCIES
//
// Uma foto num aplicativo de fiscalização não é ilustração: é uma
// AFIRMAÇÃO de que aquele peixe é aquela espécie. Se a identificação
// estiver errada, o erro sai daqui e vira identificação errada no campo
// — e decide autuação.
//
// Por isso toda foto carrega a origem, e o aplicativo mostra a origem
// junto com a imagem. Quando a origem não foi declarada, ele DIZ que não
// foi declarada, em vez de calar. É a mesma regra das normas: o
// aplicativo não afirma o que não pode sustentar.
//
// Nenhuma foto é identificada por este aplicativo. Quem identifica é
// quem fotografou ou o catálogo de onde ela veio.
// =====================================================================

/// De onde a foto veio, e quem respondeu pela identificação da espécie.
enum OrigemDaFoto {
  /// Acervo do órgão: fotografada em fiscalização ou em atividade
  /// institucional, identificada por quem a produziu.
  orgao,

  /// Catálogo de órgão ou instituição de pesquisa — ICMBio, IBAMA, MPA,
  /// universidade. A `fonte` diz qual, e é o que se cita.
  catalogo,

  /// A figura veio dentro do texto de uma norma. É a origem mais forte
  /// que existe aqui: a própria norma mostra o bicho ou a medida.
  norma,

  /// A foto está no aplicativo e ninguém declarou de onde veio. O
  /// aplicativo mostra a imagem E mostra este aviso — não some com ele.
  naoDeclarada,
}

const avisoDeOrigem = <OrigemDaFoto, String>{
  OrigemDaFoto.orgao: '',
  OrigemDaFoto.catalogo: '',
  OrigemDaFoto.norma: '',
  OrigemDaFoto.naoDeclarada:
      'ORIGEM NÃO DECLARADA. Não se sabe quem fotografou nem quem '
      'identificou a espécie nesta imagem. Use a foto como apoio, nunca '
      'como prova de identificação: confirme pelo nome científico e, na '
      'dúvida, consulte a norma nos sites oficiais.',
};

/// Uma foto de espécie, com a procedência dela.
class Foto {
  /// O nome científico, como o aplicativo escreve nas fichas.
  final String cientifico;

  /// O arquivo em assets/especies/.
  final String arquivo;

  /// De onde veio.
  final OrigemDaFoto origem;

  /// Quem se cita: o órgão, o catálogo, a norma. Vazio só quando a
  /// origem é naoDeclarada.
  final String fonte;

  /// Quem respondeu pela identificação da espécie, quando se sabe.
  final String identificacao;

  /// Uma observação sobre a imagem, quando ela precisa de uma — a fase
  /// do bicho, a parte mostrada, o que a foto não permite distinguir.
  final String observacao;

  const Foto({
    required this.cientifico,
    required this.arquivo,
    required this.origem,
    this.fonte = '',
    this.identificacao = '',
    this.observacao = '',
  });

  String get caminho => 'assets/especies/$arquivo';

  /// A linha de crédito que aparece sob a imagem.
  String get credito {
    switch (origem) {
      case OrigemDaFoto.orgao:
        return fonte.isEmpty ? 'Acervo do órgão' : fonte;
      case OrigemDaFoto.catalogo:
        return fonte;
      case OrigemDaFoto.norma:
        return 'Figura da própria norma: $fonte';
      case OrigemDaFoto.naoDeclarada:
        return 'Origem não declarada';
    }
  }

  bool get precisaDeAviso => origem == OrigemDaFoto.naoDeclarada;
}



/// De onde vieram todas as fotos que estão hoje no aplicativo.
///
/// Uma compilação recebida em 01/09/2026 sob o nome "Guia de
/// Identificação de peixes", que organiza as espécies do Anexo I da IN
/// MMA nº 53/2005. Em nenhuma das 23 páginas ela declara autor,
/// instituição ou a procedência das imagens.
const guiaSemAutoria =
    'Compilação sem autoria identificada, recebida em 01/09/2026 sob o '
    'nome "Guia de Identificação de peixes". Em 23 páginas reúne quatro '
    'blocos: os Anexos I e II da IN MMA nº 53/2005; um quadro de '
    'tamanhos e defesos que cita normas antigas; cinco normas de '
    'moratória; e o anexo do Decreto Estadual nº 63.853, de 27 de '
    'novembro de 2018, do Estado de São Paulo. Não declara autor, '
    'instituição nem a procedência das imagens.';




// ---------------------------------------------------------------------
// AS FOTOS
//
// Todas vêm do mesmo documento e todas declaram a mesma coisa: origem
// não declarada. Servem de apoio para reconhecer o bicho; não servem de
// prova de identificação, e a ficha diz isso junto com a imagem.
//
// Onde a grafia do nome científico no documento diverge da que as normas
// usam, a ficha registra as duas.
// ---------------------------------------------------------------------
const fotos = <Foto>[
  Foto(
    cientifico: 'Adelomelon beckii',
    arquivo: 'adelomelon_beckii.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Alopias superciliosus',
    arquivo: 'alopias_superciliosus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    identificacao: 'O guia escreve "Alopias supeciliosus". O aplicativo usa '
        '"Alopias superciliosus", que é a grafia das normas que ele '
        'carrega.',
  ),
  Foto(
    cientifico: 'Alopias vulpinus',
    arquivo: 'alopias_vulpinus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Aristaeomorpha foliacea',
    arquivo: 'aristaeomorpha_foliacea.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Aristeus antillensis',
    arquivo: 'aristeus_antillensis.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Artemesia longinaris',
    arquivo: 'artemesia_longinaris.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Asterina stellifera',
    arquivo: 'asterina_stellifera.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Atlantoraja castelnaui',
    arquivo: 'atlantoraja_castelnaui.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Atlantoraja cyclophora',
    arquivo: 'atlantoraja_cyclophora.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    observacao: 'Imagem de baixa resolução (162x121): serve para uma '
        'conferência grosseira, não para distinguir espécies parecidas.',
  ),
  Foto(
    cientifico: 'Atlantoraja platana',
    arquivo: 'atlantoraja_platana.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    observacao: 'Imagem de baixa resolução (153x121): serve para uma conferência grosseira, não para distinguir espécies parecidas.',
  ),
  Foto(
    cientifico: 'Bagre marinus',
    arquivo: 'bagre_marinus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Balistes capriscus',
    arquivo: 'balistes_capriscus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Balistes vetula',
    arquivo: 'balistes_vetula.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    identificacao: 'O guia escreve "Balistes veluta". O aplicativo usa "Balistes '
        'vetula", que é a grafia das normas que ele carrega.',
  ),
  Foto(
    cientifico: 'Callinectes danae',
    arquivo: 'callinectes_danae.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Carcharhinus longimanus',
    arquivo: 'carcharhinus_longimanus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Carcharias taurus',
    arquivo: 'carcharias_taurus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Carcharodon carcharias',
    arquivo: 'carcharodon_carcharias.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Cardisoma guanhumi',
    arquivo: 'cardisoma_guanhumi.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Cathorops spixii',
    arquivo: 'cathorops_spixii.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Centropomus parallelus',
    arquivo: 'centropomus_parallelus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Centropomus undecimalis',
    arquivo: 'centropomus_undecimalis.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Centropyge aurantonotus',
    arquivo: 'centropyge_aurantonotus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Cetorhinus maximus',
    arquivo: 'cetorhinus_maximus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Charonia lampas',
    arquivo: 'charonia_lampas.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Chloroscombrus chrysurus',
    arquivo: 'chloroscombrus_chrysurus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Coscinasterias tenuispina',
    arquivo: 'coscinasterias_tenuispina.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Cynoscion jamaicensis',
    arquivo: 'cynoscion_jamaicensis.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    observacao: 'Imagem de baixa resolução (291x103): serve para uma '
        'conferência grosseira, não para distinguir espécies parecidas.',
  ),
  Foto(
    cientifico: 'Cynoscion striatus',
    arquivo: 'cynoscion_striatus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    observacao: 'Imagem de baixa resolução (274x100): serve para uma '
        'conferência grosseira, não para distinguir espécies parecidas.',
  ),
  Foto(
    cientifico: 'Cyrtopleura costata',
    arquivo: 'cyrtopleura_costata.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Echinaster brasiliensis',
    arquivo: 'echinaster_brasiliensis.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    observacao: 'Imagem de baixa resolução (247x225): serve para uma conferência grosseira, não para distinguir espécies parecidas.',
  ),
  Foto(
    cientifico: 'Epinephelus itajara',
    arquivo: 'epinephelus_itajara.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Epinephelus marginatus',
    arquivo: 'epinephelus_marginatus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Eurytellina punicea',
    arquivo: 'eurytellina_punicea.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Euvola ziczac',
    arquivo: 'euvola_ziczac.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Farfantepenaeus brasiliensis',
    arquivo: 'farfantepenaeus_brasiliensis.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Farfantepenaeus paulensis',
    arquivo: 'farfantepenaeus_paulensis.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Farfantepenaeus subtilis',
    arquivo: 'farfantepenaeus_subtilis.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Genidens barbus',
    arquivo: 'genidens_barbus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    identificacao: 'O guia escreve "Genindes barbus". O aplicativo usa "Genidens '
        'barbus", que é a grafia das normas que ele carrega.',
  ),
  Foto(
    cientifico: 'Genidens genidens',
    arquivo: 'genidens_genidens.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    identificacao: 'O guia escreve "Genindes genides". O aplicativo usa "Genidens '
        'genidens", que é a grafia das normas que ele carrega.',
  ),
  Foto(
    cientifico: 'Ginglymostoma cirratum',
    arquivo: 'ginglymostoma_cirratum.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    identificacao: 'O guia escreve "Gimglymostoma cirratum". O aplicativo usa '
        '"Ginglymostoma cirratum", que é a grafia das normas que ele '
        'carrega.',
  ),
  Foto(
    cientifico: 'Gramma brasiliensis',
    arquivo: 'gramma_brasiliensis.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Gymnura altavela',
    arquivo: 'gymnura_altavela.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Hastula cinerea',
    arquivo: 'hastula_cinerea.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Heteroconger longissimus',
    arquivo: 'heteroconger_longissimus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    observacao: 'Imagem de baixa resolução (243x134): serve para uma conferência grosseira, não para distinguir espécies parecidas.',
  ),
  Foto(
    cientifico: 'Holacanthus ciliaris',
    arquivo: 'holacanthus_ciliaris.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Holacanthus tricolor',
    arquivo: 'holacanthus_tricolor.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Hyporthodus nigritus',
    arquivo: 'hyporthodus_nigritus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Hyporthodus niveatus',
    arquivo: 'hyporthodus_niveatus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Litopenaeus schmitti',
    arquivo: 'litopenaeus_schmitti.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Litopenaeus vannamei',
    arquivo: 'litopenaeus_vannamei.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Littoraria angulifera',
    arquivo: 'littoraria_angulifera.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Lopholatilus villarii',
    arquivo: 'lopholatilus_villarii.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Lutjanus cyanopterus',
    arquivo: 'lutjanus_cyanopterus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Lutjanus purpureus',
    arquivo: 'lutjanus_purpureus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Macrodon ancylodon',
    arquivo: 'macrodon_ancylodon.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Macrostrombus costatus',
    arquivo: 'macrostrombus_costatus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    identificacao: 'O guia escreve "Aliger costatus"; o aplicativo usa "Macrostrombus costatus", que é a grafia d Anexo I da Portaria GM/MMA nº 1.667/2026. Mesmo epíteto, gênero diferente: as duas grafias foram tratadas como a mesma espécie.',
  ),
  Foto(
    cientifico: 'Melampus coffeus',
    arquivo: 'melampus_coffeus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Menticirrhus littoralis',
    arquivo: 'menticirrhus_littoralis.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Mesodesma mactroides',
    arquivo: 'mesodesma_mactroides.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Metanephrops rubellus',
    arquivo: 'metanephrops_rubellus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Micropogonias furnieri',
    arquivo: 'micropogonias_furnieri.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Mugil curema',
    arquivo: 'mugil_curema.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Mullus argentinae',
    arquivo: 'mullus_argentinae.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Mustelus canis',
    arquivo: 'mustelus_canis.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Mustelus fasciatus',
    arquivo: 'mustelus_fasciatus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Mustelus schmitti',
    arquivo: 'mustelus_schmitti.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Mycteroperca acutirostris',
    arquivo: 'mycteroperca_acutirostris.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Mycteroperca bonaci',
    arquivo: 'mycteroperca_bonaci.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Mycteroperca interstitialis',
    arquivo: 'mycteroperca_interstitialis.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Mycteroperca microlepis',
    arquivo: 'mycteroperca_microlepis.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    observacao: 'Imagem de baixa resolução (261x118): serve para uma '
        'conferência grosseira, não para distinguir espécies parecidas.',
  ),
  Foto(
    cientifico: 'Mycteroperca tigris',
    arquivo: 'mycteroperca_tigris.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Mycteroperca venenosa',
    arquivo: 'mycteroperca_venenosa.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    observacao: 'Imagem de baixa resolução (241x133): serve para uma conferência grosseira, não para distinguir espécies parecidas.',
  ),
  Foto(
    cientifico: 'Myliobatis goodei',
    arquivo: 'myliobatis_goodei.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    observacao: 'Imagem de baixa resolução (168x116): serve para uma '
        'conferência grosseira, não para distinguir espécies parecidas.',
  ),
  Foto(
    cientifico: 'Negaprion brevirostris',
    arquivo: 'negaprion_brevirostris.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Ophidion holbrookii',
    arquivo: 'ophidion_holbrookii.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Opisthonema oglinum',
    arquivo: 'opisthonema_oglinum.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Paralichthys patagonicus / P. brasiliensis',
    arquivo: 'paralichthys_patagonicus_p_brasiliensis.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    identificacao: 'O guia escreve "Paralichthys patagonicus". O aplicativo usa '
        '"Paralichthys patagonicus / P. brasiliensis", que é a grafia '
        'das normas que ele carrega.',
    observacao: 'A ficha cobre duas espécies — Paralichthys patagonicus e P. '
        'brasiliensis — e esta imagem é a que o guia rotula como '
        'Paralichthys patagonicus. A imagem também é de baixa resolução '
        '(267x130).',
  ),
  Foto(
    cientifico: 'Parona signata',
    arquivo: 'parona_signata.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Penaeus schmitti',
    arquivo: 'penaeus_schmitti.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    observacao: 'Imagem de baixa resolução (283x152): serve para uma '
        'conferência grosseira, não para distinguir espécies parecidas.',
  ),
  Foto(
    cientifico: 'Peprilus paru',
    arquivo: 'peprilus_paru.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Perna perna',
    arquivo: 'perna_perna.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Pleoticus muelleri',
    arquivo: 'pleoticus_muelleri.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Plesionika edwardsii',
    arquivo: 'plesionika_edwardsii.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Polyprion americanus',
    arquivo: 'polyprion_americanus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Pomatomus saltatrix',
    arquivo: 'pomatomus_saltatrix.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Prionotus punctatus',
    arquivo: 'prionotus_punctatus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    observacao: 'Imagem de baixa resolução (275x90): serve para uma conferência '
        'grosseira, não para distinguir espécies parecidas.',
  ),
  Foto(
    cientifico: 'Psammobatis extenta',
    arquivo: 'psammobatis_extenta.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Pseudobatos horkelii',
    arquivo: 'pseudobatos_horkelii.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    identificacao: 'O guia escreve "Rhinobatos horkelii"; o aplicativo usa "Pseudobatos horkelii", que é a grafia d Anexo I da Portaria GM/MMA nº 1.667/2026. Mesmo epíteto, gênero diferente: as duas grafias foram tratadas como a mesma espécie.',
  ),
  Foto(
    cientifico: 'Pseudobatos percellens',
    arquivo: 'pseudobatos_percellens.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    identificacao: 'O guia escreve "Rhinobatos percellens"; o aplicativo usa "Pseudobatos percellens", que é a grafia d Anexo I da Portaria GM/MMA nº 1.667/2026. Mesmo epíteto, gênero diferente: as duas grafias foram tratadas como a mesma espécie.',
    observacao: 'Imagem de baixa resolução (260x96): serve para uma conferência grosseira, não para distinguir espécies parecidas.',
  ),
  Foto(
    cientifico: 'Rhincodon typus',
    arquivo: 'rhincodon_typus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Rhinoptera bonasus',
    arquivo: 'rhinoptera_bonasus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    observacao: 'Imagem de baixa resolução (177x117): serve para uma conferência grosseira, não para distinguir espécies parecidas.',
  ),
  Foto(
    cientifico: 'Rhinoptera brasiliensis',
    arquivo: 'rhinoptera_brasiliensis.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    observacao: 'Imagem de baixa resolução (130x121): serve para uma '
        'conferência grosseira, não para distinguir espécies parecidas.',
  ),
  Foto(
    cientifico: 'Rimapenaeus constrictus',
    arquivo: 'rimapenaeus_constrictus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Rioraja agassizii',
    arquivo: 'rioraja_agassizii.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Sardinella brasiliensis',
    arquivo: 'sardinella_brasiliensis.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Scarus quacamaia',
    arquivo: 'scarus_quacamaia.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Scarus trispinosus',
    arquivo: 'scarus_trispinosus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Scarus zelindae',
    arquivo: 'scarus_zelindae.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Sicyonia dorsalis',
    arquivo: 'sicyonia_dorsalis.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Sparisoma amplum',
    arquivo: 'sparisoma_amplum.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Sparisoma axillare',
    arquivo: 'sparisoma_axillare.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Sparisoma frondosum',
    arquivo: 'sparisoma_frondosum.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Sphyrna lewini',
    arquivo: 'sphyrna_lewini.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Sphyrna media',
    arquivo: 'sphyrna_media.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Sphyrna tiburo',
    arquivo: 'sphyrna_tiburo.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Sphyrna tudes',
    arquivo: 'sphyrna_tudes.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Sphyrna zygaena',
    arquivo: 'sphyrna_zygaena.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Squalus albicaudus',
    arquivo: 'squalus_albicaudus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Squatina argentina',
    arquivo: 'squatina_argentina.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Squatina guggenheim',
    arquivo: 'squatina_guggenheim.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Squatina occulta',
    arquivo: 'squatina_occulta.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Sympterygia acuta',
    arquivo: 'sympterygia_acuta.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Thunnus thynnus',
    arquivo: 'thunnus_thynnus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Tivela mactroides',
    arquivo: 'tivela_mactroides.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Tivela ventricosa',
    arquivo: 'tivela_ventricosa.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Tonna galea',
    arquivo: 'tonna_galea.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Trichiurus lepturus',
    arquivo: 'trichiurus_lepturus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Ucides cordatus',
    arquivo: 'ucides_cordatus.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Umbrina canosai',
    arquivo: 'umbrina_canosai.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
    observacao: 'Imagem de baixa resolução (284x103): serve para uma '
        'conferência grosseira, não para distinguir espécies parecidas.',
  ),
  Foto(
    cientifico: 'Xiphias gladius',
    arquivo: 'xiphias_gladius.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Xiphopenaeus kroyeri',
    arquivo: 'xiphopenaeus_kroyeri.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
  Foto(
    cientifico: 'Zapteryx brevirostris',
    arquivo: 'zapteryx_brevirostris.jpg',
    origem: OrigemDaFoto.naoDeclarada,
    fonte: guiaSemAutoria,
  ),
];

// =====================================================================
// AS ESPÉCIES QUE ENTRAM SÓ PORQUE EXISTE FOTO DELAS
//
// A ficha do aplicativo nasce de norma: tamanho mínimo na IN MMA nº
// 53/2005, ou a Lista da Portaria GM/MMA nº 1.667/2026, ou o catálogo
// de nomes da Portaria MPA nº 532/2025 quando alguma norma carregada
// cita a espécie.
//
// Estas 37 não têm nada disso. Entram porque a compilação de fotos traz
// a imagem delas, e porque quem abre o aplicativo com o bicho na mão
// procura pela foto. Ficha que não existe some da busca, e busca que
// não acha parece dizer que não há regra.
//
// A PÁGINA QUE NASCE DAQUI NÃO AFIRMA REGRA NENHUMA. Ela mostra a foto,
// mostra que a origem da foto não foi declarada, e diz em voz alta que
// nenhuma norma carregada por este aplicativo alcança a espécie.
//
// A maior parte vem do bloco de São Paulo da compilação. Aquele decreto
// é norma do Estado de São Paulo: NÃO ALCANÇA SANTA CATARINA e não foi
// carregado aqui. A ficha diz isso com todas as letras, porque a foto
// sem essa frase sugere uma proteção que em Santa Catarina não se sabe
// se existe.
// =====================================================================
const especiesSoDaFoto = <String>[
  'Adelomelon beckii',
  'Aristaeomorpha foliacea',
  'Aristeus antillensis',
  'Asterina stellifera',
  'Atlantoraja platana',
  'Callinectes danae',
  'Centropyge aurantonotus',
  'Charonia lampas',
  'Coscinasterias tenuispina',
  'Cyrtopleura costata',
  'Echinaster brasiliensis',
  'Eurytellina punicea',
  'Farfantepenaeus brasiliensis',
  'Farfantepenaeus subtilis',
  'Gramma brasiliensis',
  'Hastula cinerea',
  'Heteroconger longissimus',
  'Holacanthus ciliaris',
  'Holacanthus tricolor',
  'Litopenaeus vannamei',
  'Littoraria angulifera',
  'Melampus coffeus',
  'Mesodesma mactroides',
  'Metanephrops rubellus',
  'Mycteroperca tigris',
  'Mycteroperca venenosa',
  'Ophidion holbrookii',
  'Plesionika edwardsii',
  'Psammobatis extenta',
  'Rhinoptera bonasus',
  'Rimapenaeus constrictus',
  'Scarus quacamaia',
  'Sicyonia dorsalis',
  'Squalus albicaudus',
  'Tivela mactroides',
  'Tivela ventricosa',
  'Tonna galea',
];

const _decretoSP = 'o Decreto Estadual nº 63.853, de 27 de novembro de '
    '2018, do ESTADO DE SÃO PAULO';

/// Sob que norma a compilação lista cada uma delas.
///
/// NÃO É REGRA DO APLICATIVO: é procedência da imagem. Nenhuma dessas
/// normas foi lida nem carregada aqui.
const listadaNoGuiaSob = <String, String>{
  'Adelomelon beckii': _decretoSP,
  'Aristaeomorpha foliacea': _decretoSP,
  'Aristeus antillensis': _decretoSP,
  'Asterina stellifera': _decretoSP,
  'Atlantoraja platana': _decretoSP,
  'Callinectes danae': 
      'a Portaria N-24, de 26 de julho de 1983',
  'Centropyge aurantonotus': _decretoSP,
  'Charonia lampas': _decretoSP,
  'Coscinasterias tenuispina': _decretoSP,
  'Cyrtopleura costata': _decretoSP,
  'Echinaster brasiliensis': _decretoSP,
  'Eurytellina punicea': _decretoSP,
  'Farfantepenaeus brasiliensis': _decretoSP,
  'Farfantepenaeus subtilis': _decretoSP,
  'Gramma brasiliensis': _decretoSP,
  'Hastula cinerea': _decretoSP,
  'Heteroconger longissimus': _decretoSP,
  'Holacanthus ciliaris': _decretoSP,
  'Holacanthus tricolor': _decretoSP,
  'Litopenaeus vannamei': _decretoSP,
  'Littoraria angulifera': _decretoSP,
  'Melampus coffeus': _decretoSP,
  'Mesodesma mactroides': _decretoSP,
  'Metanephrops rubellus': _decretoSP,
  'Mycteroperca tigris': _decretoSP,
  'Mycteroperca venenosa': _decretoSP,
  'Ophidion holbrookii': _decretoSP,
  'Plesionika edwardsii': _decretoSP,
  'Psammobatis extenta': _decretoSP,
  'Rhinoptera bonasus': _decretoSP,
  'Rimapenaeus constrictus': _decretoSP,
  'Scarus quacamaia': _decretoSP,
  'Sicyonia dorsalis': _decretoSP,
  'Squalus albicaudus': _decretoSP,
  'Tivela mactroides': _decretoSP,
  'Tivela ventricosa': _decretoSP,
  'Tonna galea': _decretoSP,
};

/// O parágrafo que a ficha de uma espécie só-da-foto exibe.
String porQueSoTemFoto(String cientifico) {
  final sob = listadaNoGuiaSob[cientifico];
  final base = 'Esta espécie está no aplicativo porque existe foto dela '
      'na compilação de imagens. NENHUMA NORMA CARREGADA POR ESTE '
      'APLICATIVO REGULA ESTA ESPÉCIE — não há tamanho mínimo, defeso, '
      'área nem proibição de captura a apurar aqui.';
  if (sob == null) return base;
  final fecho = sob == _decretoSP
      ? '\n\nA compilação a lista sob $sob. Norma estadual de outro '
          'estado NÃO ALCANÇA SANTA CATARINA, e ela não foi carregada '
          'neste aplicativo.\n\nPara saber se há regra em Santa '
          'Catarina, consulte a legislação correspondente nos sites '
          'oficiais.'
      : '\n\nA compilação a lista sob $sob. Este aplicativo não '
          'carrega essa norma: não se sabe o texto dela nem se continua '
          'em vigor. É preciso procurar a norma nos sites oficiais.';
  return base + fecho;
}

Map<String, Foto>? _porCientifico;

/// A foto de uma espécie, quando há.
Foto? fotoDe(String cientifico) {
  _porCientifico ??= {for (final f in fotos) f.cientifico: f};
  return _porCientifico![cientifico];
}

int get quantasFotos => fotos.length;

int get quantasFotosSemOrigem =>
    fotos.where((f) => f.origem == OrigemDaFoto.naoDeclarada).length;

/// Quantas espécies entram no aplicativo só pela foto.
int get quantasSoDaFoto => especiesSoDaFoto.length;

